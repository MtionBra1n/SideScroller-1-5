<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="Dark City Test" tilewidth="16" tileheight="16" tilecount="400" columns="20">
 <image source="City Tileset.png" width="320" height="320"/>
</tileset>
