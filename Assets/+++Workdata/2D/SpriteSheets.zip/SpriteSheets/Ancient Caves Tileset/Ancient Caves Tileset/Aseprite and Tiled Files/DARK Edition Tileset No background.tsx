<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="DARK Edition Tileset No background" tilewidth="16" tileheight="16" tilecount="224" columns="14">
 <image source="../../../01 DARK - Platformer Starter Pack/DARK Edition/Tileset/DARK Edition Tileset No background.png" width="224" height="256"/>
</tileset>
